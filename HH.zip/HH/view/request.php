<?php

require_once '../functions/request_functions.php';
require_once '../actions/request_actions.php';
require_once '../functions/transactions_functions.php';



if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}



// Retrieve logged-in user's role and ID from the session
$user = $_SESSION['user'];
$user_id = $user['id'];
$user_role = $user['role'];

// Fetch data based on the user's role
$requestedProperties = [];
if ($user_role == 1) { // Super admin
    $requestedProperties = getAllRequestedProperties();
} else if ($user_role == 2) { // Regular user
    $requestedProperties = getPropertiesByUser($user_id);
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HavenHomes</title>
    <style>
        /* General Reset */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        /* Title Bar Styling */
        .title-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #34495e;
            color: white;
            padding: 10px 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            margin-left: 60px;
            font-family: Georgia;
        }

         /* Sidebar Styling */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 250px;
            background-color: #2c3e50;
            color: white;
            transform: translateX(-100%);
            transition: transform 0.3s ease;
            z-index: 1000;
            padding-top: 60px;
        }

        .sidebar.open {
            transform: translateX(0);
        }

        .sidebar a {
            display: block;
            padding: 15px 20px;
            text-decoration: none;
            color: white;
            font-size: 18px;
            transition: background-color 0.3s ease;
        }

        .sidebar a:hover {
            background-color: #34495e;
        }


         /* Style for dropdown */
        .dropdown {
            position: relative;
        }

        .dropdown-content {
            display: none;
            flex-direction: column;
            background-color: #f9f9f9;
            position: relative;
            padding-left: 20px; /* Indent for sublinks */
        }

        .dropdown-content a {
            display: block;
            padding: 5px 0;
            text-decoration: none;
            color: #000;
        }

        .dropdown-content a:hover {
            background-color: #ddd;
        }

        .dropdown .show {
            display: flex;
        }

        .toggle-btn {
            position: fixed;
            top: 10px;
            left: 15px;
            background-color: #1abc9c;
            border: none;
            color: white;
            padding: 10px 15px;
            font-size: 9px;
            cursor: pointer;
            z-index: 1100;
            border-radius: 5px;

        }

        .toggle-btn:hover {
            background-color: #16a085;
        }

        /* Content Area */
        .content {
            margin-left: 20px;
            padding: 20px;
            transition: margin-left 0.3s ease;
        }

        .content.shifted {
            margin-left: 270px;
        }

        .nav-links-container {
            flex-grow: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .nav-links {
            display: flex;
            gap: 20px;
        }

        .nav-links a {
            text-decoration: none;
            color: white;
            font-size: 18px;
            transition: color 0.3s ease;
        }

        .nav-links a:hover,
        .nav-links a.active {
            color: #1abc9c;
            font-weight: bold;


        }


         .back {
            font-size: 18px;
        }

        .back a {
            text-decoration: none;
            color: white;
            transition: color 0.3s ease;
        }

        .back a:hover {
            color: #1abc9c;
        }

        .property-card {
            display: flex;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin: 10px;
            margin-left: 100px;
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 1000px;
        }

        .property-card img {
            max-width: 500px;
            margin-right: 20px;
            border-radius: 8px;
        }

        .property-card-details {
            flex-grow: 1;
        }

        .property-card-actions {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-right: 100px;
        }

        .property-card-actions button {
            padding: 8px 16px;
            background-color: #1abc9c;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            width: 200px;
            transition: background-color 0.3s ease;
        }

        .property-card-actions button:hover {
            background-color: #16a085;
        }

        .property-card-details h3 {
            margin: 0;
            font-size: 20px;
            margin-left: 20px;
        }

        .property-card-details p {
            margin: 5px 0;
            margin-left: 20px;
        }



        .search-bar-container {
            margin-left: 20px;
            margin-right: 20px;
        }

        .search-bar {
            padding: 5px 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 200px;
        }

        .requests {
            font-size: 18px;
        }

        .requests a {
            text-decoration: none;
            color: white;
            transition: color 0.3s ease;
        }

        .requests a:hover {
            color: #1abc9c;
        }

        /* Add Property Button Styling */
        .add-property-container {
            text-align: center;
            margin: 20px 0;
        }

        .add-property-btn {
            background-color: #1abc9c;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .add-property-btn:hover {
            background-color: #16a085;
        }


        .edit-property-container {
            text-align: center;
            margin: 20px 0;
        }

        .edit-property-btn {
            background-color: #1abc9c;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .edit-property-btn:hover {
            background-color: #16a085;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            overflow-y: scroll;
        }

        .modal-content {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .close-btn {
            float: right;
            font-size: 18px;
            cursor: pointer;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-submit {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #1abc9c;
            color: white;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .form-submit:hover {
            background-color: #16a085;
        }

        .search-bar-container {
            display: flex;
            align-items: center;
            gap: 10px; /* Adds space between the input field and the button */
        }

        .search-btn {
            padding: 5px 15px;
            font-size: 16px;
            color: white;
            background-color: #1abc9c;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .search-btn:hover {
            background-color: #16a085;
        }

        #no-results-message {
            font-size: 18px;
            font-weight: bold;
            margin-top: 20px;
            color: red;
            text-align: center;
        }


    </style>
</head>
<body>


    <div class="title-bar">
        <!-- Logo Section -->
        <div class="logo">HH</div>

        <!-- Centered Navigation Links -->
        <div class="nav-links-container">
            <div class="nav-links">
                <a href="request.php" class="active">Requests</a>
            </div>
        </div>

       
        <div class="back">
            <a href="javascript:history.back()">Back</a>
        </div>
    </div>



   

    <!-- Display property requests -->
    <div id="properties-container">
        <?php if (!empty($requestedProperties)): ?>
            <?php foreach ($requestedProperties as $property): ?>
                <div class="property-card">
                    <img src="../assets/<?php echo $property['image_url']; ?>" alt="Property Image">
                    <div class="property-card-details">
                        <h3><?php echo htmlspecialchars($property['address']); ?></h3>
                        <p>Price: <?php echo htmlspecialchars('$'. $property['price']); ?></p>
                        <p>Property Type: <?php echo htmlspecialchars($property['property_type']); ?></p>
                        <p>Status: <?php echo htmlspecialchars($property['status']); ?></p>
                        <p>Requested On: <?php echo htmlspecialchars($property['request_date']); ?></p>

                        <?php if ($user_role == 1): // Additional details for super admin ?>
                            <p>Requested By: <?php echo htmlspecialchars($property['first_name'] . ' ' . $property['last_name'] ); ?></p>
                            <p>Email: <?php echo htmlspecialchars($property['email']); ?></p>
                            <p>Phone: <?php echo htmlspecialchars($property['phone']); ?></p>
                        <?php endif; ?>
                    </div>
                <div class="property-card-actions">
                <button style="margin-top: 80px"><a href="?delete_request_id=<?php echo $property['request_id']; ?>" style="color: red;" onclick="return confirm('Are you sure you want to delete this request?');" >Delete</a></button>
                <!-- <?php if ($user_role == 1):?>
                    <button onclick="openModal('confirmTransactionModal')">Confirm Transaction </button>
                    <?php endif; ?> -->
                </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No property requests found.</p>
        <?php endif; ?>
    </div>





 <script>
    // Open a specific modal
    function openModal(modalId) {
        document.getElementById(modalId).style.display = 'flex';
    }

    // Close a specific modal
    function closeModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }
</script>



    <script src="../assets/js/script.js"></script>
</body>
</html>