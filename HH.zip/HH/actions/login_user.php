<?php

require_once '../db/database.php';
require_once '../functions/auth_functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    
    // Login the user
    $result = loginUser($email, $password);
    
    if ($result['success']) {
        // Redirect to the appropriate dashboard based on role
        $role = $_SESSION['user']['role'];
        if ($role == 1) {
            header('Location: ../view/dashboard.php');
        } else {
            header('Location: ../view/explore_homes.php');
        }
        exit();
    } else {
        header('Location: ../view/login.php?error=' . urlencode($result['message']));
        exit();
    }
}

?>