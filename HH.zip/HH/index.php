<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HavenHomes</title>
    <style>

/* General Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}


html, body {
    margin: 0;
    padding: 0;
    height: 100%;
    width: 100%;
}

/* Body Styling */
body {
    font-family: 'Arial', sans-serif;
    background: #34495e;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    color: #333;
    overflow: hidden;
}

/* Centered Container */
div {
    text-align: center;
    background-color: #fff;
    padding: 40px 20px;
    border-radius: 12px;
    box-shadow: 0 10px 15px rgba(0, 0, 0, 0.2);
    width: 90%;
    max-width: 400px;
    animation: fadeIn 1.2s ease-in-out;
}

/* Heading Style */
h1 {
    font-size: 2.4em;
    font-weight: bold;
    color: #1abc9c;
    margin-bottom: 15px;
}

/* Paragraph Style */
p {
    font-size: 1.2em;
    color: #555;
    margin-bottom: 25px;

}

/* Link Styled as Button */
a {
    display: inline-block;
    text-decoration: none;
    font-size: 1em;
    font-weight: bold;
    color: white;
    background-color: #1abc9c;
    padding: 12px 25px;
    border-radius: 8px;
    box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
    transition: background-color 0.3s ease, transform 0.2s ease;
}

/* Hover Effect */
a:hover {
    background-color: #16a085;
    transform: scale(1.05);
}

/* Active/Pressed State */
a:active {
    transform: scale(0.95);
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
}

/* Animation for Fade-In Effect */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

    </style>
</head>
<body>
    <div>
        <h1>HavenHomes</h1>
        <p><em>Feel at Home</em></p>
        <a href="view/login.php">Get Started</a>
    </div>
</body>
</html>
