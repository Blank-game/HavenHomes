<?php

// Database Configuration
//define('DB_SERVER', 'buvxhm2z7yocg8l1iifp-mysql.services.clever-cloud.com:3306');
//define('DB_USERNAME', 'uh89vi5jemnznh8a');
//define('DB_PASSWORD', 'hyo9PS4m2MUx85uoTlCc');
//define('DB_DATABASE', 'buvxhm2z7yocg8l1iifp');

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'havenhomes');


// Start session
session_start();

// Database Connection
$db_connection = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE);

// Check connection
if ($db_connection->connect_error) {
    die("Connection failed: " . $db_connection->connect_error);
}


?>