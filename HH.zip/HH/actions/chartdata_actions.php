<?php
require_once '../db/database.php';


$buyerTypeQuery = "
    SELECT u.buyer_type, COUNT(DISTINCT t.user_id) AS user_count
    FROM transactions t
    INNER JOIN users u ON t.user_id = u.user_id
    GROUP BY u.buyer_type
";
$buyerTypeResult = $db_connection->query($buyerTypeQuery);

$buyerTypeData = [];
while ($row = $buyerTypeResult->fetch_assoc()) {
    $buyerTypeData[] = $row;
}

// Fetch data for "Amount of Users Acquired by Each Agent"
$agentQuery = "SELECT CONCAT(a.fname, ' ', a.lname) AS agent_name, COUNT(t.user_id) AS user_count 
               FROM agent a 
               LEFT JOIN transactions t ON a.agent_id = t.agent_id 
               GROUP BY a.agent_id";
$agentResult = $db_connection->query($agentQuery);
$agentData = [];
while ($row = $agentResult->fetch_assoc()) {
    $agentData[] = $row;
}

// Close connection
$db_connection->close();
?>