<?php
require_once '../functions/property_functions.php';





if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}


if (isset($_GET['property_id'])) {
    $property_id = $_GET['property_id'];
} else {
    die("Error: No property ID specified.");
}

// Find the property to edit based on the property ID
$property_to_edit = null;
foreach ($properties as $property) {
    if ($property['property_id'] == $property_id) {
        $property_to_edit = $property;
        break;
    }
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Get the submitted data
    $property_id = $_POST['property_id'];
    $address = $_POST['address'];
    $price = $_POST['price'];
    $property_type = $_POST['property_type'];
    $status = $_POST['status'];
    $date_listed = $_POST['date_listed'];


  $image_url = $property_to_edit['image_url']; // Default to the current image URL
if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
    $target_dir = "../assets/";
    $image_name = uniqid() . "_" . basename($_FILES['image']['name']);
    $target_file = $target_dir . $image_name;

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
        $image_url = $image_name;
    } else {
        echo "<script>alert('Failed to upload image. Keeping the existing image.');</script>";
        //echo "Upload error: " . $_FILES['image']['error'];

    }
} elseif (!isset($_FILES['image']) || $_FILES['image']['error'] != UPLOAD_ERR_NO_FILE) {
    // Handle unexpected errors if a file upload attempt fails for other reasons
    echo "<script>alert('Unexpected error during image upload. Keeping the existing image.');</script>";
}

    
    
    // Update property table
    $update_property_query = "UPDATE property SET address = ?, price = ?, property_type = ?, status = ?, date_listed = ?, image_url = ? WHERE property_id = ?";
    $stmt = getDbConnection()->prepare($update_property_query);
    $stmt->bind_param("ssssssi", $address, $price, $property_type, $status, $date_listed, $image_url, $property_id);
    
    $stmt->execute();

    // Update the specific table (based on property type)
     if ($property_type == 'apartment') {
        $num_rooms = $_POST['num_rooms_apartment'];
        $num_bathrooms = $_POST['num_bathrooms_apartment'];
        $num_floors = $_POST['num_floors_apartment'];

        $update_apartment = "UPDATE apartment SET num_rooms = ?, num_bathrooms = ?, num_floors = ? WHERE property_id = ?";
        $stmt = getDbConnection()->prepare($update_apartment);
        $stmt->bind_param("iiii", $num_rooms, $num_bathrooms, $num_floors, $property_id);
    } elseif ($property_type == 'bungalow') {
        $num_rooms = $_POST['num_rooms_bungalow'];
        $num_bathrooms = $_POST['num_bathrooms_bungalow'];
        $num_floors = $_POST['num_floors_bungalow'];
        $lot_size = $_POST['lot_size_bungalow'];

        $update_bungalow = "UPDATE bungalow SET num_rooms = ?, num_bathrooms = ?, num_floors = ?, lot_size = ? WHERE property_id = ?";
        $stmt = getDbConnection()->prepare($update_bungalow);
        $stmt->bind_param("iiiii", $num_rooms, $num_bathrooms, $num_floors, $lot_size, $property_id);
    } elseif ($property_type == 'detached_house') {
        $num_rooms = $_POST['num_rooms_detached'];
        $num_bathrooms = $_POST['num_bathrooms_detached'];
        $garage_size = $_POST['garage_size'];
        $parking_space = $_POST['parking_space'];
        $lot_size = $_POST['lot_size_detached'];

        $update_detached = "UPDATE detached_house SET num_rooms = ?, num_bathrooms = ?, garage_size = ?, parking_space = ?, lot_size = ? WHERE property_id = ?";
        $stmt = getDbConnection()->prepare($update_detached);
        $stmt->bind_param("iissii", $num_rooms, $num_bathrooms, $garage_size, $parking_space, $lot_size, $property_id);
    } elseif ($property_type == 'mansion') {
        $num_rooms = $_POST['num_rooms_mansion'];
        $num_bathrooms = $_POST['num_bathrooms_mansion'];
        $luxury_features = $_POST['luxury_features'];
        $lot_size = $_POST['lot_size_mansion'];

        $update_mansion = "UPDATE mansion SET num_rooms = ?, num_bathrooms = ?, luxury_features = ?, lot_size = ? WHERE property_id = ?";
        $stmt = getDbConnection()->prepare($update_mansion);
        $stmt->bind_param("iisii", $num_rooms, $num_bathrooms, $luxury_features, $lot_size, $property_id);
    }
    
    $stmt->execute();




    // Redirect or success message
    echo "<script>
        alert('Property edited successfully!');  // Show the success message
        window.location.href = '../view/dashboard.php';  // Redirect to dashboard
      </script>";
}

?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HavenHomes</title>
    <style>
        /* General Reset */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        /* Title Bar Styling */
        .title-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #34495e;
            color: white;
            padding: 10px 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
        }

        .nav-links-container {
            flex-grow: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .nav-links {
            display: flex;
            gap: 20px;
        }

        .nav-links a {
            text-decoration: none;
            color: white;
            font-size: 18px;
            transition: color 0.3s ease;
        }

        .nav-links a:hover,
        .nav-links a.active {
            color: #1abc9c;
            font-weight: bold;


        }

        .property-card {
            display: flex;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin: 10px;
            margin-left: 100px;
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 1000px;
        }

        .property-card img {
            max-width: 500px;
            margin-right: 20px;
            border-radius: 8px;
        }

        .property-card-details {
            flex-grow: 1;
        }

        .property-card-actions {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-right: 100px;
        }

        .property-card-actions button {
            padding: 8px 16px;
            background-color: #1abc9c;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            width: 200px;
            transition: background-color 0.3s ease;
        }

        .property-card-actions button:hover {
            background-color: #16a085;
        }

        .property-card-details h3 {
            margin: 0;
            font-size: 20px;
            margin-left: 20px;
        }

        .property-card-details p {
            margin: 5px 0;
            margin-left: 20px;
        }



        .search-bar-container {
            margin-left: 20px;
            margin-right: 20px;
        }

        .search-bar {
            padding: 5px 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 200px;
        }

        .requests {
            font-size: 18px;
        }

        .requests a {
            text-decoration: none;
            color: white;
            transition: color 0.3s ease;
        }

        .requests a:hover {
            color: #1abc9c;
        }

        /* Add Property Button Styling */
        .add-property-container {
            text-align: center;
            margin: 20px 0;
        }

        .add-property-btn {
            background-color: #1abc9c;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .add-property-btn:hover {
            background-color: #16a085;
        }


        .edit-property-container {
            text-align: center;
            /*margin: 20px 0;*/
            margin-left: 350px;
        }

        .edit-property-btn {
            background-color: #1abc9c;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .edit-property-btn:hover {
            background-color: #16a085;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            overflow-y: scroll;
        }

        .modal-content {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .close-btn {
            float: right;
            font-size: 18px;
            cursor: pointer;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-submit {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #1abc9c;
            color: white;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .form-submit:hover {
            background-color: #16a085;
        }

        .search-bar-container {
            display: flex;
            align-items: center;
            gap: 10px; /* Adds space between the input field and the button */
        }

        .search-btn {
            padding: 5px 15px;
            font-size: 16px;
            color: white;
            background-color: #1abc9c;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .search-btn:hover {
            background-color: #16a085;
        }

        #no-results-message {
            font-size: 18px;
            font-weight: bold;
            margin-top: 20px;
            color: red;
            text-align: center;
        }


    </style>
</head>
<body>
    <div class="title-bar">

        <div class="requests">
            <a href="javascript:history.back()">Back</a>
        </div>
        
    </div>


   <div class="edit-property-container">
    <div class="modal-content">
        <h2>Edit Property</h2>
        <?php if ($property_to_edit): ?>
        <form id="edit-property-form" action="edit_property.php?property_id=<?php echo $property_id; ?>" method="POST" enctype="multipart/form-data">
             
            <input type="hidden" name="property_id" value="<?php echo htmlspecialchars($property_id); ?>">
            <div class="form-group">
                <label for="address">Address</label>
                <input type="text" id="address" name="address" value="<?php echo $property_to_edit['address']; ?>" required>
            </div>
            <div class="form-group">
                <label for="price">Price</label>
                <input type="number" id="price" name="price" value="<?php echo $property_to_edit['price']; ?>" required>
            </div>
            <div class="form-group">
                <label for="property_type">Property Type</label>
                <select id="property_type" name="property_type" onchange="togglePropertyField()" required>
                    <!-- <option value="">-- Select Property Type --</option> -->
                    <option value="apartment" <?php echo $property_to_edit['property_type'] == 'apartment' ? 'selected' : ''; ?>>Apartment</option>
                    <option value="bungalow" <?php echo $property_to_edit['property_type'] == 'bungalow' ? 'selected' : ''; ?>>Bungalow</option>
                    <option value="detached_house" <?php echo $property_to_edit['property_type'] == 'detached_house' ? 'selected' : ''; ?>>Detached House</option>
                    <option value="mansion" <?php echo $property_to_edit['property_type'] == 'mansion' ? 'selected' : ''; ?>>Mansion</option>
                </select>
            </div>
            <div class="form-group">
                <label for="image">Image</label>
                <input type="file" id="image" name="image" accept="image/*">
                <img src="../assets/<?php echo $property_to_edit['image_url']; ?>" alt="Property Image" width="100" />
            </div>
            <div class="form-group">
                <label for="status">Status</label>
                <select id="status" name="status" required>
                    <option value="For Sale" <?php echo $property_to_edit['status'] == 'For Sale' ? 'selected' : ''; ?>>For Sale</option>
                    <option value="Sold" <?php echo $property_to_edit['status'] == 'Sold' ? 'selected' : ''; ?>>Sold</option>
                </select>
            </div>
            <div class="form-group">
                <label for="date_listed">Date Listed</label>
                <input type="date" id="date_listed" name="date_listed" value="<?php echo $property_to_edit['date_listed']; ?>" required>
            </div>

            <!-- Show specific fields based on property type -->
            <?php if ($property_to_edit['property_type'] == 'apartment'): ?>
                <div id="apartment-fields" class="property-specific-fields">
                    <div class="form-group">
                        <label for="num_rooms_apartment">Number of Rooms</label>
                        <input type="number" id="num_rooms_apartment" name="num_rooms_apartment" value="<?php echo $property_to_edit['num_rooms_apartment']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="num_bathrooms_apartment">Number of Bathrooms</label>
                        <input type="number" id="num_bathrooms_apartment" name="num_bathrooms_apartment" value="<?php echo $property_to_edit['num_bathrooms_apartment']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="num_floors_apartment">Number of Floors</label>
                        <input type="number" id="num_floors_apartment" name="num_floors_apartment" value="<?php echo $property_to_edit['num_floors_apartment']; ?>">
                    </div>
                </div>
            <?php elseif ($property_to_edit['property_type'] == 'bungalow'): ?>
                <div id="bungalow-fields" class="property-specific-fields">
                    <div class="form-group">
                        <label for="num_rooms_bungalow">Number of Rooms</label>
                        <input type="number" id="num_rooms_bungalow" name="num_rooms_bungalow" value="<?php echo $property_to_edit['num_rooms_bungalow']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="num_bathrooms_bungalow">Number of Bathrooms</label>
                        <input type="number" id="num_bathrooms_bungalow" name="num_bathrooms_bungalow" value="<?php echo $property_to_edit['num_bathrooms_bungalow']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="num_floors_bungalow">Number of Floors</label>
                        <input type="number" id="num_floors_bungalow" name="num_floors_bungalow" value="<?php echo $property_to_edit['num_floors_bungalow']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="lot_size_bungalow">Lot Size</label>
                        <input type="number" id="lot_size_bungalow" name="lot_size_bungalow" value="<?php echo $property_to_edit['lot_size_bungalow']; ?>">
                    </div>
                </div>
                <!-- Bungalow fields -->
            <?php elseif ($property_to_edit['property_type'] == 'detached_house'): ?>
                <div id="detached-house-fields" class="property-specific-fields">
                    <div class="form-group">
                        <label for="num_rooms_detached">Number of Rooms</label>
                        <input type="number" id="num_rooms_detached" name="num_rooms_detached" value="<?php echo $property_to_edit['num_rooms_detached']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="num_bathrooms_detached">Number of Bathrooms</label>
                        <input type="number" id="num_bathrooms_detached" name="num_bathrooms_detached" value="<?php echo $property_to_edit['num_bathrooms_detached']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="garage_size">Garage Size</label>
                        <input type="text" id="garage_size" name="garage_size" value="<?php echo $property_to_edit['garage_size']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="parking_space">Parking Space</label>
                        <input type="text" id="parking_space" name="parking_space" value="<?php echo $property_to_edit['parking_space']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="lot_size_detached">Lot Size</label>
                        <input type="number" id="lot_size_detached" name="lot_size_detached" value="<?php echo $property_to_edit['lot_size_detached']; ?>">
                    </div>
                </div>
                <!-- Detached House fields -->
            <?php elseif ($property_to_edit['property_type'] == 'mansion'): ?>
                <div id="mansion-fields" class="property-specific-fields">
                    <div class="form-group">
                        <label for="num_rooms_mansion">Number of Rooms</label>
                        <input type="number" id="num_rooms_mansion" name="num_rooms_mansion" value="<?php echo $property_to_edit['num_rooms_mansion']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="num_bathrooms_mansion">Number of Bathrooms</label>
                        <input type="number" id="num_bathrooms_mansion" name="num_bathrooms_mansion" value="<?php echo $property_to_edit['num_bathrooms_mansion']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="luxury_features">Number of Floors</label>
                        <input type="text" id="luxury_features" name="luxury_features" value="<?php echo $property_to_edit['luxury_features']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="lot_size_mansion">Number of Floors</label>
                        <input type="number" id="lot_size_mansion" name="lot_size_mansion" value="<?php echo $property_to_edit['lot_size_mansion']; ?>">
                    </div>
                </div>
                <!-- Mansion fields -->
            <?php endif; ?>
            <?php endif; ?>
           
            <button type="submit" class="form-submit">Save Changes</button> 
        </form>
    </div>
</div>




    <script>
    
    function openModal(modalId) {
        document.getElementById(modalId).style.display = 'flex';
    }

    
    function closeModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }
</script>


    <script>
    window.onload = togglePropertyField;
</script>


    <script src="../assets/js/script.js"></script>
</body>
</html>
