<?php
require_once '../db/database.php';
require_once '../functions/property_functions.php';

// Get the database connection
$conn = getDbConnection();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // General property fields
    $address = $_POST['address'];
    $price = $_POST['price'];
    $property_type = $_POST['property_type'];
    $status = $_POST['status'];
    $date_listed = $_POST['date_listed'];

    // Image upload handling
    $image_url = null; // Initialize as null

    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/jpg'];
        $max_size = 2 * 1024 * 1024; // 2MB
        $upload_dir = '../assets/images/';

        // Ensure upload directory exists
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }

        $file_type = $_FILES['image']['type'];
        $file_size = $_FILES['image']['size'];
        $original_name = basename($_FILES['image']['name']);
        $unique_name = time() . '_' . $original_name;

        // Validate file type and size
        if (!in_array($file_type, $allowed_types)) {
            die('Invalid file type. Only .jpg, .jpeg, .png files are allowed.');
        }
        if ($file_size > $max_size) {
            die('File size exceeds the 2MB limit.');
        }

        // Move file to upload directory
        $target_path = $upload_dir . $unique_name;
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) {
            $image_url = $target_path;
        } else {
            die('Failed to upload the image.');
        }
    }

    // Insert into property table
    $query = "INSERT INTO property (address, price, property_type, image_url, status, date_listed) 
              VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ssssss', $address, $price, $property_type, $image_url, $status, $date_listed);

    if ($stmt->execute()) {
        $property_id = $stmt->insert_id;

        // Insert into property-specific table
        switch ($property_type) {
            case 'apartment':
                $num_rooms = $_POST['num_rooms_apartment'];
                $num_bathrooms = $_POST['num_bathrooms_apartment'];
                $num_floors = $_POST['num_floors_apartment'];
                $query = "INSERT INTO apartment (property_id, num_rooms, num_bathrooms, num_floors) 
                          VALUES (?, ?, ?, ?)";
                $stmt = $conn->prepare($query);
                $stmt->bind_param('iiii', $property_id, $num_rooms, $num_bathrooms, $num_floors);
                break;

            case 'bungalow':
                $num_rooms = $_POST['num_rooms_bungalow'];
                $num_bathrooms = $_POST['num_bathrooms_bungalow'];
                $num_floors = $_POST['num_floors_bungalow'];
                $lot_size = $_POST['lot_size_bungalow'];
                $query = "INSERT INTO bungalow (property_id, num_rooms, num_bathrooms, num_floors, lot_size) 
                          VALUES (?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($query);
                $stmt->bind_param('iiiii', $property_id, $num_rooms, $num_bathrooms, $num_floors, $lot_size);
                break;

            case 'detached_house':
                $num_rooms = $_POST['num_rooms_detached'];
                $num_bathrooms = $_POST['num_bathrooms_detached'];
                $garage_size = $_POST['garage_size'];
                $parking_space = $_POST['parking_space'];
                $lot_size = $_POST['lot_size_detached'];
                $query = "INSERT INTO detached_house (property_id, num_rooms, num_bathrooms, garage_size, parking_space, lot_size) 
                          VALUES (?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($query);
                $stmt->bind_param('iiiiii', $property_id, $num_rooms, $num_bathrooms, $garage_size, $parking_space, $lot_size);
                break;

            case 'mansion':
                $num_rooms = $_POST['num_rooms_mansion'];
                $num_bathrooms = $_POST['num_bathrooms_mansion'];
                $luxury_features = $_POST['luxury_features'];
                $lot_size = $_POST['lot_size_mansion'];
                $query = "INSERT INTO mansion (property_id, num_rooms, num_bathrooms, luxury_features, lot_size) 
                          VALUES (?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($query);
                $stmt->bind_param('iiisi', $property_id, $num_rooms, $num_bathrooms, $luxury_features, $lot_size);
                break;

            default:
                break;
        }

        if (isset($stmt)) {
            $stmt->execute();
        }

        echo "<script>
            alert('Property added successfully!');
            window.location.href = '../view/dashboard.php';
        </script>";
    } else {
        echo "Failed to add property: " . $conn->error;
    }
}

// Handle property deletion
if (isset($_GET['delete_id'])) {
    $propertyIdToDelete = intval($_GET['delete_id']);
    if (deleteProperty($propertyIdToDelete)) {
        echo "<script>
            alert('Property deleted successfully!');
            window.location.href = '../view/dashboard.php';
        </script>";
    } else {
        echo "Failed to delete property: " . $conn->error;
    }
}
?>