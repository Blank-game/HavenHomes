<?php
require_once '../actions/user_actions.php';




if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HavenHomes</title>
    <style>
        /* General Reset */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        /* Title Bar Styling */
        .title-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #34495e;
            color: white;
            padding: 10px 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            margin-left: 60px;
            font-family: Georgia;
        }

         /* Sidebar Styling */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 250px;
            background-color: #2c3e50;
            color: white;
            transform: translateX(-100%);
            transition: transform 0.3s ease;
            z-index: 1000;
            padding-top: 60px;
        }

        .sidebar.open {
            transform: translateX(0);
        }

        .sidebar a {
            display: block;
            padding: 15px 20px;
            text-decoration: none;
            color: white;
            font-size: 18px;
            transition: background-color 0.3s ease;
        }

        .sidebar a:hover {
            background-color: #34495e;
        }


         /* Style for dropdown */
        .dropdown {
            position: relative;
        }

        .dropdown-content {
            display: none;
            flex-direction: column;
            background-color: #f9f9f9;
            position: relative;
            padding-left: 20px; /* Indent for sublinks */
        }

        .dropdown-content a {
            display: block;
            padding: 5px 0;
            text-decoration: none;
            color: #000;
        }

        .dropdown-content a:hover {
            background-color: #ddd;
        }

        .dropdown .show {
            display: flex;
        }

        .toggle-btn {
            position: fixed;
            top: 10px;
            left: 15px;
            background-color: #1abc9c;
            border: none;
            color: white;
            padding: 10px 15px;
            font-size: 9px;
            cursor: pointer;
            z-index: 1100;
            border-radius: 5px;

        }

        .toggle-btn:hover {
            background-color: #16a085;
        }

        /* Content Area */
        .content {
            margin-left: 20px;
            padding: 20px;
            transition: margin-left 0.3s ease;
        }

        .content.shifted {
            margin-left: 270px;
        }

        .nav-links-container {
            flex-grow: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .nav-links {
            display: flex;
            gap: 20px;
        }

        .nav-links a {
            text-decoration: none;
            color: white;
            font-size: 18px;
            transition: color 0.3s ease;
        }

        .nav-links a:hover,
        .nav-links a.active {
            color: #1abc9c;
            font-weight: bold;


        }

        

        .back {
            font-size: 18px;
        }

        .back a {
            text-decoration: none;
            color: white;
            transition: color 0.3s ease;
        }

        .back a:hover {
            color: #1abc9c;
        }

        
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 18px;
            text-align: left;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
        }
        th {
            background-color: #34495e;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .delete-btn {
            background-color: #e74c3c;
            color: white;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            border-radius: 4px;
        }
        .delete-btn:hover {
            background-color: #c0392b;
        }

        


    </style>
</head>
<body>

    <button class="toggle-btn" onclick="toggleSidebar()">☰</button>
    <div class="sidebar" id="sidebar">
        <a href="dashboard.php">Home</a>
        <a href="user_management.php">User Management</a>
        <a href="agents.php">Agents</a>
    <div class="dropdown">
        <a href="transactions.php" onclick="toggleDropdown(event)">Transactions</a>
        <div class="dropdown-content" id="transactionsDropdown">
            <a href="table_data.php">Table Data</a>
            <a href="chart_data.php">Chart Data</a>
        </div>
    </div>
    </div>

    <div class="title-bar">
        <!-- Logo Section -->
        <div class="logo">HH</div>

    <script>
         const sidebar = document.getElementById('sidebar');
         const content = document.getElementById('content');

    function toggleSidebar() {
        sidebar.classList.toggle('open');
        content.classList.toggle('shifted');
    }

    function toggleDropdown(event) {
        event.preventDefault(); // Prevent navigation on click
        const dropdown = document.getElementById('transactionsDropdown');
        dropdown.classList.toggle('show');
    }
    </script>

        <!-- Centered Navigation Links -->
        <div class="nav-links-container">
            <div class="nav-links"> 
                <a href="user_management.php">User Management</a>
            </div>
        </div>

        <div class="back">
            <a href="javascript:history.back()">Back</a>
        </div>

    </div>


    <table>
        <thead>
            <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Buyer Type</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($users)): ?>
                <tr>
                    <td colspan="6">No users found.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?= htmlspecialchars($user['fname']) ?></td>
                        <td><?= htmlspecialchars($user['lname']) ?></td>
                        <td><?= htmlspecialchars($user['phone']) ?></td>
                        <td><?= htmlspecialchars($user['email']) ?></td>
                        <td><?= htmlspecialchars($user['buyer_type']) ?></td>
                        <td>
                            <a href="?delete_user_id=<?= $user['user_id'] ?>" 
                               class="delete-btn" 
                               onclick="return confirm('Are you sure you want to delete this user?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>





    <script src="../assets/js/script.js"></script>
</body>
</html>
