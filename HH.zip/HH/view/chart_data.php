<?php
require_once '../actions/chartdata_actions.php';



if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HavenHomes</title>
       <style>
        /* General Reset */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        /* Title Bar Styling */
        .title-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #34495e;
            color: white;
            padding: 10px 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            margin-left: 60px;
            font-family: Georgia;
        }

         /* Sidebar Styling */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 250px;
            background-color: #2c3e50;
            color: white;
            transform: translateX(-100%);
            transition: transform 0.3s ease;
            z-index: 1000;
            padding-top: 60px;
        }

        .sidebar.open {
            transform: translateX(0);
        }

        .sidebar a {
            display: block;
            padding: 15px 20px;
            text-decoration: none;
            color: white;
            font-size: 18px;
            transition: background-color 0.3s ease;
        }

        .sidebar a:hover {
            background-color: #34495e;
        }


         /* Style for dropdown */
        .dropdown {
            position: relative;
        }

        .dropdown-content {
            display: none;
            flex-direction: column;
            background-color: #f9f9f9;
            position: relative;
            padding-left: 20px; /* Indent for sublinks */
        }

        .dropdown-content a {
            display: block;
            padding: 5px 0;
            text-decoration: none;
            color: #000;
        }

        .dropdown-content a:hover {
            background-color: #ddd;
        }

        .dropdown .show {
            display: flex;
        }

        .toggle-btn {
            position: fixed;
            top: 10px;
            left: 15px;
            background-color: #1abc9c;
            border: none;
            color: white;
            padding: 10px 15px;
            font-size: 9px;
            cursor: pointer;
            z-index: 1100;
            border-radius: 5px;

        }

        .toggle-btn:hover {
            background-color: #16a085;
        }

        /* Content Area */
        .content {
            margin-left: 20px;
            padding: 20px;
            transition: margin-left 0.3s ease;
        }

        .content.shifted {
            margin-left: 270px;
        }

        .nav-links-container {
            flex-grow: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .nav-links {
            display: flex;
            gap: 20px;
        }

        .nav-links a {
            text-decoration: none;
            color: white;
            font-size: 18px;
            transition: color 0.3s ease;
        }

        .nav-links a:hover,
        .nav-links a.active {
            color: #1abc9c;
            font-weight: bold;


        }

        

        .back {
            font-size: 18px;
        }

        .back a {
            text-decoration: none;
            color: white;
            transition: color 0.3s ease;
        }

        .back a:hover {
            color: #1abc9c;
        }

        
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 18px;
            text-align: left;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
        }
        th {
            background-color: #34495e;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .delete-btn {
            background-color: #e74c3c;
            color: white;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            border-radius: 4px;
        }
        .delete-btn:hover {
            background-color: #c0392b;
        }

        .edit-btn {
            background-color: #ffd22b;
            color: white;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            border-radius: 4px;
        }

        .edit-btn:hover {
            background-color: #feb204;
        }


        /* Add Property Button Styling */
        .add-transaction-container {
            text-align: center;
            margin: 20px 0;
        }

        .add-transaction-btn {
            background-color: #1abc9c;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .add-transaction-btn:hover {
            background-color: #16a085;
        }


         /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            overflow-y: scroll;
        }

        .modal-content {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .close-btn {
            float: right;
            font-size: 18px;
            cursor: pointer;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-submit {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #1abc9c;
            color: white;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .form-submit:hover {
            background-color: #16a085;
        }
        

        /* Container style */
        .chart-container {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            gap: 50px;
            margin-top: 20px;
        }

        
        .chart-wrapper {
            width: 300px;
            height: 300px;
        }


    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <button class="toggle-btn" onclick="toggleSidebar()">☰</button>
    <div class="sidebar" id="sidebar">
        <a href="dashboard.php">Home</a>
        <a href="user_management.php">User Management</a>
        <a href="agents.php">Agents</a>
    <div class="dropdown">
        <a onclick="toggleDropdown(event)">Transactions</a>
        <div class="dropdown-content" id="transactionsDropdown">
            <a href="table_data.php">Table Data</a>
            <a href="chart_data.php">Chart Data</a>
        </div>
    </div>
    </div>

    <div class="title-bar">
        <!-- Logo Section -->
        <div class="logo">HH</div>

    <script>
         const sidebar = document.getElementById('sidebar');
         const content = document.getElementById('content');

    function toggleSidebar() {
        sidebar.classList.toggle('open');
        content.classList.toggle('shifted');
    }

    function toggleDropdown(event) {
        event.preventDefault(); // Prevent navigation on click
        const dropdown = document.getElementById('transactionsDropdown');
        dropdown.classList.toggle('show');
    }
    </script>

        <!-- Centered Navigation Links -->
        <div class="nav-links-container">
            <div class="nav-links"> 
                <a href="chart_data.php">Transactions - Chart Data</a>
            </div>
        </div>

        <div class="back">
            <a href="javascript:history.back()">Back</a>
        </div>

    </div>

    <div class="chart-container">
    <h1 style="margin-left: 50px;">Paying Users by Buyer Type</h1>
    <div class="chart-wrapper">
    <canvas id="buyerTypeChart"></canvas>
    </div>
    <h1 style="margin-left: 50px;">Paying Users by Agent</h1>
    <div class="chart-wrapper">
    <canvas id="agentChart"></canvas>
    </div>
    </div>
</body>


<script>
    // Buyer Type Chart
    const buyerTypeData = <?= json_encode($buyerTypeData); ?>;
    const buyerTypeLabels = buyerTypeData.map(data => data.buyer_type);
    const buyerTypeCounts = buyerTypeData.map(data => data.user_count);

    new Chart(document.getElementById('buyerTypeChart'), {
        type: 'pie',
        data: {
            labels: buyerTypeLabels,
            datasets: [{
                label: 'Users by Buyer Type',
                data: buyerTypeCounts,
                backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0'],
            }]
        },
    });

    // Agent Chart
    const agentData = <?= json_encode($agentData); ?>;
    const agentLabels = agentData.map(data => data.agent_name);
    const agentCounts = agentData.map(data => data.user_count);

    new Chart(document.getElementById('agentChart'), {
        type: 'pie',
        data: {
            labels: agentLabels,
            datasets: [{
                label: 'Users by Agent',
                data: agentCounts,
                backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF'],
            }]
        },
    });
</script>
</html>
