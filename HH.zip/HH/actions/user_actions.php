<?php
require_once '../functions/user_functions.php';

// Delete a user
if (isset($_GET['delete_user_id'])) {
    $deleteUserId = intval($_GET['delete_user_id']);
    $deleteQuery = "DELETE FROM users WHERE user_id = $deleteUserId";
    if ($db_connection->query($deleteQuery)) {
        header("Location: user_management.php");
        exit();
    } else {
        echo "Error deleting user: " . $db_connection->error;
    }
}

$users = fetchUsers($db_connection);


// Delete an agent
if (isset($_GET['delete_agent_id'])) {
    $deleteAgentId = intval($_GET['delete_agent_id']);
    $deleteQuery = "DELETE FROM agent WHERE agent_id = $deleteAgentId";
    if ($db_connection->query($deleteQuery)) {
        header("Location: agents.php");
        exit();
    } else {
        echo "Error deleting agent: " . $db_connection->error;
    }
}

$agents = fetchAgents($db_connection);




// Get the database connection
$conn = getDbConnection();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // General property fields
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];



  
        // Insert into agent table
        $query = "INSERT INTO agent (fname, lname, phone, email) 
                  VALUES ('$fname', '$lname', '$phone', '$email')";
        if ($conn->query($query)) {
            $agent_id = $conn->insert_id;


            if (isset($query)) {
                $conn->query($query);
            }

            echo "<script>
        alert('Agent added successfully!');  // Show the success message
        window.location.href = '../view/agents.php';  // Redirect to agents page
      </script>";
        } 
        
    
}



// Update agent in the database
if (isset($_POST['update_agent'])) {
    $agent_id = $_POST['agent_id'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];

    $db = getDbConnection();

    // Check if the email already exists for another agent
    $query = "SELECT COUNT(*) AS count FROM agent WHERE email = ? AND agent_id != ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param("si", $email, $agent_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    // If email already exists for another agent, show an error
    if ($row['count'] > 0) {
        echo "<script>
        alert('Error: Email already exists for another agent.');
        window.location.href = '../view/edit_agent.php?agent_id=$agent_id'; // Redirect back to the edit page
        </script>";
        exit();
    }

    // If email is unchanged, skip it in the update query
    $query = "SELECT email FROM agent WHERE agent_id = ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param("i", $agent_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $current_email = $result->fetch_assoc()['email'];

    if ($email === $current_email) {
        // If the email is unchanged, update without it
        $query = "UPDATE agent SET fname = ?, lname = ?, phone = ? WHERE agent_id = ?";
        $stmt = $db->prepare($query);
        $stmt->bind_param("sssi", $fname, $lname, $phone, $agent_id);
    } else {
        // If the email has changed, include it in the update query
        $query = "UPDATE agent SET fname = ?, lname = ?, phone = ?, email = ? WHERE agent_id = ?";
        $stmt = $db->prepare($query);
        $stmt->bind_param("ssssi", $fname, $lname, $phone, $email, $agent_id);
    }

    if ($stmt->execute()) {
        echo "<script>
        alert('Agent edited successfully!');  // Show the success message
        window.location.href = '../view/agents.php';  // Redirect to agents page
        </script>";
    } else {
        echo "Error updating agent: " . $stmt->error;
    }

    $stmt->close();
    
}







?>