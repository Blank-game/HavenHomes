<?php

require_once '../functions/property_functions.php';
require_once '../actions/property_actions.php';

// Get the database connection
$connection = getDbConnection();

// Initialize query and parameters
$query = "SELECT p.property_id, p.address, p.price, p.property_type, p.image_url, p.status, p.date_listed,
                     a.num_rooms AS num_rooms_apartment, a.num_bathrooms AS num_bathrooms_apartment, a.num_floors AS num_floors_apartment,
                     b.num_rooms AS num_rooms_bungalow, b.num_bathrooms AS num_bathrooms_bungalow, b.num_floors AS num_floors_bungalow, b.lot_size AS lot_size_bungalow,
                     d.num_rooms AS num_rooms_detached, d.num_bathrooms AS num_bathrooms_detached, d.garage_size, d.parking_space, d.lot_size AS lot_size_detached,
                     m.num_rooms AS num_rooms_mansion, m.num_bathrooms AS num_bathrooms_mansion, m.luxury_features, m.lot_size AS lot_size_mansion
              FROM Property p
              LEFT JOIN Apartment a ON p.property_id = a.property_id
              LEFT JOIN Bungalow b ON p.property_id = b.property_id
              LEFT JOIN Detached_House d ON p.property_id = d.property_id
              LEFT JOIN Mansion m ON p.property_id = m.property_id";
$params = [];

// Check if there's a search query
if (isset($_GET['search']) && !empty(trim($_GET['search']))) {
    $search = trim($_GET['search']);
    $query .= " WHERE "; // Add WHERE clause

    if (is_numeric($search)) {
        // Search specifically by price for numeric input
        $query .= "price = ?";
        $params = [$search];
    } else {
        // Search by address for non-numeric input
        $query .= "address LIKE ?";
        $likeSearch = '%' . $search . '%';
        $params = [$likeSearch];
    }
}



// Prepare and execute the statement
$stmt = $connection->prepare($query);
if ($stmt === false) {
    die('Error preparing query: ' . $connection->error);
}

// Bind parameters
if (!empty($params)) {
    $stmt->bind_param(str_repeat('s', count($params)), ...$params);
}

// Execute and fetch results
$stmt->execute();
$result = $stmt->get_result();
$property_results = $result->fetch_all(MYSQLI_ASSOC);



if (!empty($property_results)) {
    $properties = $property_results;  // Pass results to the frontend
} else {
    $properties = [];  // Empty array to avoid errors in the frontend
}



?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

    <title>HavenHomes</title>
    <style>
        /* General Reset */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        /* Title Bar Styling */
        .title-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #34495e;
            color: white;
            padding: 10px 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            margin-left: 60px;
            font-family: Georgia;
        }

         /* Sidebar Styling */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 250px;
            background-color: #2c3e50;
            color: white;
            transform: translateX(-100%);
            transition: transform 0.3s ease;
            z-index: 1000;
            padding-top: 60px;
        }

        .sidebar.open {
            transform: translateX(0);
        }

        .sidebar a {
            display: block;
            padding: 15px 20px;
            text-decoration: none;
            color: white;
            font-size: 18px;
            transition: background-color 0.3s ease;
        }

        .sidebar a:hover {
            background-color: #34495e;
        }


         /* Style for dropdown */
        .dropdown {
            position: relative;
        }

        .dropdown-content {
            display: none;
            flex-direction: column;
            background-color: #f9f9f9;
            position: relative;
            padding-left: 20px; /* Indent for sublinks */
        }

        .dropdown-content a {
            display: block;
            padding: 5px 0;
            text-decoration: none;
            color: #000;
        }

        .dropdown-content a:hover {
            background-color: #ddd;
        }

        .dropdown .show {
            display: flex;
        }

        .toggle-btn {
            position: fixed;
            top: 10px;
            left: 15px;
            background-color: #1abc9c;
            border: none;
            color: white;
            padding: 10px 15px;
            font-size: 9px;
            cursor: pointer;
            z-index: 1100;
            border-radius: 5px;

        }

        .toggle-btn:hover {
            background-color: #16a085;
        }

        /* Content Area */
        .content {
            margin-left: 20px;
            padding: 20px;
            transition: margin-left 0.3s ease;
        }

        .content.shifted {
            margin-left: 270px;
        }

        .nav-links-container {
            flex-grow: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .nav-links {
            display: flex;
            gap: 20px;
        }

        .nav-links a {
            text-decoration: none;
            color: white;
            font-size: 18px;
            transition: color 0.3s ease;
        }

        .nav-links a:hover,
        .nav-links a.active {
            color: #1abc9c;
            font-weight: bold;


        }


         .back {
            font-size: 18px;
        }

        .back a {
            text-decoration: none;
            color: white;
            transition: color 0.3s ease;
        }

        .back a:hover {
            color: #1abc9c;
        }

        .property-card {
            display: flex;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin: 10px;
            margin-left: 100px;
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 1000px;
        }

        .property-card img {
            max-width: 500px;
            margin-right: 20px;
            border-radius: 8px;
        }

        .property-card-details {
            flex-grow: 1;
        }

        .property-card-actions {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-right: 100px;
        }

        .property-card-actions button {
            padding: 8px 16px;
            background-color: #1abc9c;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            width: 200px;
            transition: background-color 0.3s ease;
        }

        .property-card-actions button:hover {
            background-color: #16a085;
        }

        .property-card-details h3 {
            margin: 0;
            font-size: 20px;
            margin-left: 20px;
        }

        .property-card-details p {
            margin: 5px 0;
            margin-left: 20px;
        }



        .search-bar-container {
            margin-left: 20px;
            margin-right: 20px;
        }

        .search-bar {
            padding: 5px 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 200px;
        }

        .requests {
            font-size: 18px;
        }

        .requests a {
            text-decoration: none;
            color: white;
            transition: color 0.3s ease;
        }

        .requests a:hover {
            color: #1abc9c;
        }

        /* Add Property Button Styling */
        .add-property-container {
            text-align: center;
            margin: 20px 0;
        }

        .add-property-btn {
            background-color: #1abc9c;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .add-property-btn:hover {
            background-color: #16a085;
        }


        .edit-property-container {
            text-align: center;
            margin: 20px 0;
        }

        .edit-property-btn {
            background-color: #1abc9c;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .edit-property-btn:hover {
            background-color: #16a085;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            overflow-y: scroll;
        }

        .modal-content {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .close-btn {
            float: right;
            font-size: 18px;
            cursor: pointer;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-submit {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #1abc9c;
            color: white;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .form-submit:hover {
            background-color: #16a085;
        }

        .search-bar-container {
            display: flex;
            align-items: center;
            gap: 10px; /* Adds space between the input field and the button */
        }

        .search-btn {
            padding: 5px 15px;
            font-size: 16px;
            color: white;
            background-color: #1abc9c;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .search-btn:hover {
            background-color: #16a085;
        }

        #no-results-message {
            font-size: 18px;
            font-weight: bold;
            margin-top: 20px;
            color: red;
            text-align: center;
        }

        .footer {
    background-color: #34495e;
    color: #fff;
    padding: 20px 0;
    font-family: Arial, sans-serif;
}

.footer-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 15px;
}

.footer-section {
    flex: 1;
    min-width: 200px;
    margin: 10px 20px;
}

.footer-section h4 {
    margin-bottom: 15px;
    font-size: 18px;
    color: #fff;
}

.footer-section ul {
    list-style: none;
    padding: 0;
}

.footer-section ul li {
    margin-bottom: 10px;
}

.footer-section ul li a {
    text-decoration: none;
    color: #fff;
    transition: color 0.3s;
}

.footer-section ul li a:hover {
    color: #f4a261;
}

.social-icons a {
    text-decoration: none;
    color: #fff;
    margin-right: 10px;
    font-size: 18px;
    transition: color 0.3s;
}

.social-icons a:hover {
    color: #1abc9c;
}

.footer-bottom {
    text-align: center;
    margin-top: 20px;
    border-top: 1px solid #444;
    padding-top: 10px;
}

.footer-bottom p {
    margin: 0;
    font-size: 14px;
}

@media (max-width: 768px) {
    .footer-container {
        flex-direction: column;
        align-items: center;
    }

    .footer-section {
        text-align: center;
    }
}



    </style>
</head>
<body>

    <button class="toggle-btn" onclick="toggleSidebar()">☰</button>
    <div class="sidebar" id="sidebar">
        <a href="dashboard.php">Home</a>
        <a href="user_management.php">User Management</a>
        <a href="agents.php">Agents</a>
    <div class="dropdown">
        <a href="transactions.php" onclick="toggleDropdown(event)">Transactions</a>
        <div class="dropdown-content" id="transactionsDropdown">
            <a href="table_data.php">Table Data</a>
            <a href="chart_data.php">Chart Data</a>
        </div>
    </div>
    
    </div>

    <div class="title-bar">
        <!-- Logo Section -->
        <div class="logo">HH</div>

    <script>
         const sidebar = document.getElementById('sidebar');
         const content = document.getElementById('content');

    function toggleSidebar() {
        sidebar.classList.toggle('open');
        content.classList.toggle('shifted');
    }

    function toggleDropdown(event) {
        event.preventDefault(); // Prevent navigation on click
        const dropdown = document.getElementById('transactionsDropdown');
        dropdown.classList.toggle('show');
    }
    </script>

     

          <div class="back">
            <a href="javascript:history.back()">Back</a>
        </div>
    </div>


   <?php if (empty($properties)): ?>
   	<h3>No results found</h3>
   	<?php else: ?>
   		<?php if ($_SESSION['user']['role'] == 1): ?>
    <!-- Property Cards Display -->
    <div id="properties-container">
        <!-- Property Card Example -->
        <?php foreach ($properties as $property): ?>
            <div class="property-card" data-price="<?php echo $property['price']; ?>" data-address="<?php echo htmlspecialchars($property['address']); ?>" data-type="<?php echo $property['property_type']; ?>">
                <img src="../assets/<?php echo $property['image_url']; ?>" alt="Property Image">
                <div class="property-card-details">
                    <h3><?php echo htmlspecialchars($property['address']); ?></h3>
                    <p>Price: $<?php echo number_format($property['price']); ?></p>
                    <p>Type: <?php echo ucfirst($property['property_type']); ?></p>
                    <p>Status: <?php echo htmlspecialchars($property['status']); ?></p>
                    <p>Date Listed: <?php echo htmlspecialchars($property['date_listed']); ?></p>

                    <!-- Display specific fields for each property type -->
                    <?php if ($property['property_type'] === 'apartment'): ?>
                        <p>Rooms: <?php echo $property['num_rooms_apartment']; ?></p>
                        <p>Bathrooms: <?php echo $property['num_bathrooms_apartment']; ?></p>
                        <p>Floors: <?php echo $property['num_floors_apartment']; ?></p>
                    <?php elseif ($property['property_type'] === 'bungalow'): ?>
                        <p>Rooms: <?php echo $property['num_rooms_bungalow']; ?></p>
                        <p>Bathrooms: <?php echo $property['num_bathrooms_bungalow']; ?></p>
                        <p>Floors: <?php echo $property['num_floors_bungalow']; ?></p>
                        <p>Lot Size: <?php echo $property['lot_size_bungalow']; ?> sq ft</p>
                    <?php elseif ($property['property_type'] === 'detached_house'): ?>
                        <p>Rooms: <?php echo $property['num_rooms_detached']; ?></p>
                        <p>Bathrooms: <?php echo $property['num_bathrooms_detached']; ?></p>
                        <p>Garage Size: <?php echo $property['garage_size']; ?></p>
                        <p>Parking Space: <?php echo $property['parking_space']; ?></p>
                        <p>Lot Size: <?php echo $property['lot_size_detached']; ?> sq ft</p>
                    <?php elseif ($property['property_type'] === 'mansion'): ?>
                        <p>Rooms: <?php echo $property['num_rooms_mansion']; ?></p>
                        <p>Bathrooms: <?php echo $property['num_bathrooms_mansion']; ?></p>
                        <p>Luxury Features: <?php echo htmlspecialchars($property['luxury_features']); ?></p>
                        <p>Lot Size: <?php echo $property['lot_size_mansion']; ?> sq ft</p>
                    <?php endif; ?>
                </div>
                <div class="property-card-actions">
                    <button class="edit" style="margin-top: 60px;"><a href="../view/edit_property.php?property_id=<?php echo $property['property_id']; ?>">Edit</a></button>

                    <button class="delete"><a href="?delete_id=<?php echo $property['property_id'];?>" onclick="return confirm('Are you sure you want to delete this property?');" style="color: red;">Delete</a></button>
                </div>
            </div>
        <?php endforeach; ?>

    </div>
    <?php else: ?>
    	<div id="properties-container">
        <!-- Property Card Example -->
        <?php foreach ($properties as $property): ?>
            <div class="property-card" data-price="<?php echo $property['price']; ?>" data-address="<?php echo htmlspecialchars($property['address']); ?>" data-type="<?php echo $property['property_type']; ?>">
                <img src="../assets/<?php echo $property['image_url']; ?>" alt="Property Image">
                <div class="property-card-details">
                    <h3><?php echo htmlspecialchars($property['address']); ?></h3>
                    <p>Price: $<?php echo number_format($property['price']); ?></p>
                    <p>Type: <?php echo ucfirst($property['property_type']); ?></p>
                    <p>Status: <?php echo htmlspecialchars($property['status']); ?></p>
                    <p>Date Listed: <?php echo htmlspecialchars($property['date_listed']); ?></p>

                    <!-- Display specific fields for each property type -->
                    <?php if ($property['property_type'] === 'apartment'): ?>
                        <p>Rooms: <?php echo $property['num_rooms_apartment']; ?></p>
                        <p>Bathrooms: <?php echo $property['num_bathrooms_apartment']; ?></p>
                        <p>Floors: <?php echo $property['num_floors_apartment']; ?></p>
                    <?php elseif ($property['property_type'] === 'bungalow'): ?>
                        <p>Rooms: <?php echo $property['num_rooms_bungalow']; ?></p>
                        <p>Bathrooms: <?php echo $property['num_bathrooms_bungalow']; ?></p>
                        <p>Floors: <?php echo $property['num_floors_bungalow']; ?></p>
                        <p>Lot Size: <?php echo $property['lot_size_bungalow']; ?> sq ft</p>
                    <?php elseif ($property['property_type'] === 'detached_house'): ?>
                        <p>Rooms: <?php echo $property['num_rooms_detached']; ?></p>
                        <p>Bathrooms: <?php echo $property['num_bathrooms_detached']; ?></p>
                        <p>Garage Size: <?php echo $property['garage_size']; ?></p>
                        <p>Parking Space: <?php echo $property['parking_space']; ?></p>
                        <p>Lot Size: <?php echo $property['lot_size_detached']; ?> sq ft</p>
                    <?php elseif ($property['property_type'] === 'mansion'): ?>
                        <p>Rooms: <?php echo $property['num_rooms_mansion']; ?></p>
                        <p>Bathrooms: <?php echo $property['num_bathrooms_mansion']; ?></p>
                        <p>Luxury Features: <?php echo htmlspecialchars($property['luxury_features']); ?></p>
                        <p>Lot Size: <?php echo $property['lot_size_mansion']; ?> sq ft</p>
                    <?php endif; ?>
                </div>
                <div class="property-card-actions">
                    <form method="POST" action="../actions/request_actions.php">
                        <input type="hidden" name="property_id" value="<?php echo $property['property_id']; ?>"> 
                        <button type="submit" style="margin-top: 80px;">Request Property</button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>

    </div>
    	<?php endif; ?>
<?php endif; ?>



    <footer class="footer">
    <div class="footer-container">
        <div class="footer-section">
            <h4>About Us</h4>
            <p>Your trusted real estate partner, helping you find your dream property with ease.</p>
        </div>
        <div class="footer-section">
            <h4>Contact Us</h4>
            <p>Email: havenhomes@gmail.com</p>
            <p>Phone: +23345678901</p>
            <p>Address: 123 Dream Street, Brixton</p>
        </div>
        <div class="footer-section">
            <h4>Follow Us</h4>
            <div class="social-icons">
                <a href="#"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-linkedin-in"></i></a>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; 2024 HavenHomes. All rights reserved.</p>
    </div>
</footer>

  



    <script>
    // Open a specific modal
    function openModal(modalId) {
        document.getElementById(modalId).style.display = 'flex';
    }

    // Close a specific modal
    function closeModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }
</script>


    <script>
    window.onload = togglePropertyField;
</script>


    <script src="../assets/js/script.js"></script>
</body>
</html>