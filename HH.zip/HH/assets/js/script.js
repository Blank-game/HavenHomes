function togglePropertyFields() {
    const propertyType = document.getElementById('property_type').value;

    // Hide all specific property fields
    document.getElementById('apartment-fields').style.display = 'none';
    document.getElementById('bungalow-fields').style.display = 'none';
    document.getElementById('detached-house-fields').style.display = 'none';
    document.getElementById('mansion-fields').style.display = 'none';

    // Show fields based on selected property type
    if (propertyType === 'apartment') {
        document.getElementById('apartment-fields').style.display = 'block';
    } else if (propertyType === 'bungalow') {
        document.getElementById('bungalow-fields').style.display = 'block';
    } else if (propertyType === 'detached_house') {
        document.getElementById('detached-house-fields').style.display = 'block';
    } else if (propertyType === 'mansion') {
        document.getElementById('mansion-fields').style.display = 'block';
    }
}




// Toggle active class on navigation
        const navLinks = document.querySelectorAll('.nav-links a');
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                //e.preventDefault();
                navLinks.forEach(link => link.classList.remove('active'));
                e.target.classList.add('active');

                const selectedType = e.target.textContent.toLowerCase().replace(' ', '-');
                filterProperties(selectedType);
            });
        });

        // Filter properties by type
        function filterProperties(type) {
            const properties = document.querySelectorAll('.property-card');
            properties.forEach(property => {
                const propertyType = property.getAttribute('data-type');
                if (type === 'all-properties' || propertyType === type) {
                    property.style.display = 'flex';
                } else {
                    property.style.display = 'none';
                }
            });
        }



    function togglePropertyField() {
    const propertyType = document.getElementById('property_type').value;
    const propertySections = document.querySelectorAll('.property-specific-fields');
    propertySections.forEach(section => section.style.display = 'none');
    
    const selectedSection = document.getElementById(`${propertyType}-fields`);
    if (selectedSection) {
        selectedSection.style.display = 'block';
    }
}




document.querySelector('.search-btn').addEventListener('click', function () {
    const searchQuery = document.getElementById('search-bar').value.trim().toLowerCase();
    const propertyCards = document.querySelectorAll('.property-card');
    let resultsFound = false;

    propertyCards.forEach(card => {
        const address = card.getAttribute('data-address').toLowerCase();
        const price = card.getAttribute('data-price').replace(/,/g, '');

        if (address.includes(searchQuery) || price.includes(searchQuery)) {
            card.style.display = 'block'; // Show matching card
            resultsFound = true;
        } else {
            card.style.display = 'none'; // Hide non-matching card
        }
    });

    // Display "No results found" message if no matches
    document.getElementById('no-results-message').style.display = resultsFound ? 'none' : 'block';
});