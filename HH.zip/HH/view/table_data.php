<?php
require_once '../actions/transactions_actions.php';




if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit();
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HavenHomes</title>
    <style>
        /* General Reset */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        /* Title Bar Styling */
        .title-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #34495e;
            color: white;
            padding: 10px 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            margin-left: 60px;
            font-family: Georgia;
        }

         /* Sidebar Styling */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 250px;
            background-color: #2c3e50;
            color: white;
            transform: translateX(-100%);
            transition: transform 0.3s ease;
            z-index: 1000;
            padding-top: 60px;
        }

        .sidebar.open {
            transform: translateX(0);
        }

        .sidebar a {
            display: block;
            padding: 15px 20px;
            text-decoration: none;
            color: white;
            font-size: 18px;
            transition: background-color 0.3s ease;
        }

        .sidebar a:hover {
            background-color: #34495e;
        }


         /* Style for dropdown */
        .dropdown {
            position: relative;
        }

        .dropdown-content {
            display: none;
            flex-direction: column;
            background-color: #f9f9f9;
            position: relative;
            padding-left: 20px; /* Indent for sublinks */
        }

        .dropdown-content a {
            display: block;
            padding: 5px 0;
            text-decoration: none;
            color: #000;
        }

        .dropdown-content a:hover {
            background-color: #ddd;
        }

        .dropdown .show {
            display: flex;
        }

        .toggle-btn {
            position: fixed;
            top: 10px;
            left: 15px;
            background-color: #1abc9c;
            border: none;
            color: white;
            padding: 10px 15px;
            font-size: 9px;
            cursor: pointer;
            z-index: 1100;
            border-radius: 5px;

        }

        .toggle-btn:hover {
            background-color: #16a085;
        }

        /* Content Area */
        .content {
            margin-left: 20px;
            padding: 20px;
            transition: margin-left 0.3s ease;
        }

        .content.shifted {
            margin-left: 270px;
        }

        .nav-links-container {
            flex-grow: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .nav-links {
            display: flex;
            gap: 20px;
        }

        .nav-links a {
            text-decoration: none;
            color: white;
            font-size: 18px;
            transition: color 0.3s ease;
        }

        .nav-links a:hover,
        .nav-links a.active {
            color: #1abc9c;
            font-weight: bold;


        }

        

        .back {
            font-size: 18px;
        }

        .back a {
            text-decoration: none;
            color: white;
            transition: color 0.3s ease;
        }

        .back a:hover {
            color: #1abc9c;
        }

        
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 18px;
            text-align: left;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
        }
        th {
            background-color: #34495e;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .delete-btn {
            background-color: #e74c3c;
            color: white;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            border-radius: 4px;
        }
        .delete-btn:hover {
            background-color: #c0392b;
        }

        .edit-btn {
        	background-color: #ffd22b;
            color: white;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            border-radius: 4px;
        }

        .edit-btn:hover {
            background-color: #feb204;
        }


        /* Add Property Button Styling */
        .add-transaction-container {
            text-align: center;
            margin: 20px 0;
        }

        .add-transaction-btn {
            background-color: #1abc9c;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .add-transaction-btn:hover {
            background-color: #16a085;
        }


         /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            overflow-y: scroll;
        }

        .modal-content {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .close-btn {
            float: right;
            font-size: 18px;
            cursor: pointer;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-submit {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #1abc9c;
            color: white;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .form-submit:hover {
            background-color: #16a085;
        }
        


    </style>
</head>
<body>

    <button class="toggle-btn" onclick="toggleSidebar()">☰</button>
    <div class="sidebar" id="sidebar">
        <a href="dashboard.php">Home</a>
        <a href="user_management.php">User Management</a>
        <a href="agents.php">Agents</a>
    <div class="dropdown">
        <a onclick="toggleDropdown(event)">Transactions</a>
        <div class="dropdown-content" id="transactionsDropdown">
            <a href="table_data.php">Table Data</a>
            <a href="chart_data.php">Chart Data</a>
        </div>
    </div>
    </div>

    <div class="title-bar">
        <!-- Logo Section -->
        <div class="logo">HH</div>

    <script>
         const sidebar = document.getElementById('sidebar');
         const content = document.getElementById('content');

    function toggleSidebar() {
        sidebar.classList.toggle('open');
        content.classList.toggle('shifted');
    }

    function toggleDropdown(event) {
        event.preventDefault(); // Prevent navigation on click
        const dropdown = document.getElementById('transactionsDropdown');
        dropdown.classList.toggle('show');
    }
    </script>

        <!-- Centered Navigation Links -->
        <div class="nav-links-container">
            <div class="nav-links"> 
                <a href="table_data.php">Transactions - Table Data</a>
            </div>
        </div>

        <div class="back">
            <a href="javascript:history.back()">Back</a>
        </div>

    </div>



   <?php if ($result->num_rows > 0) { 
    echo "<table border='1'>
            <tr>
                <th>Buyer</th>
                <th>Agent</th>
                <th>Property Address</th>
                <th>Transaction Date</th>
                <th>Payment Status</th>
                <th>Actions</th>
            </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['user_full_name']}</td>
                <td>{$row['agent_full_name']}</td>
                <td>{$row['property_address']}</td>
                <td>{$row['transaction_date']}</td>
                <td>{$row['payment_status']}</td>
                <td>
                    <a href='edit_transaction.php?id={$row['transaction_id']}' class='edit-btn'>Edit</a> 
                    <a href='../actions/delete_transaction.php?id={$row['transaction_id']}' class='delete-btn' onclick='return confirm(\"Are you sure you want to delete this transaction?\");'>Delete</a>
                </td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "No transactions found.";
} ?>

    <div class="add-transaction-container">
        <button class="add-transaction-btn" onclick="openModal('addTransactionModal')">Add Transaction</button>
    </div>

    <!-- Add Transaction Modal -->
    <div id="addTransactionModal" class="modal">
    <div class="modal-content">
        <span class="close-btn" onclick="closeModal('addTransactionModal')">&times;</span>
        <h2>Add New Transaction</h2>
        <form id="add-agent-form" action="../actions/transactions_actions.php" method="POST">
            <div class="form-group">
                <label for="user_id">Buyer:</label>
                <select id="user_id" name="user_id" required>
                    <option value="">-- Select Buyer --</option>
                        <?php
                        $users_query = "SELECT user_id, CONCAT(fname, ' ', lname) AS full_name FROM users";
                        $users_result = $db_connection->query($users_query);
                        while ($user = $users_result->fetch_assoc()) {
                            echo "<option value='{$user['user_id']}'>{$user['full_name']}</option>";
                        }
                        ?>
                </select><br><br>
            </div>
            <div class="form-group">
                <label for="agent_id">Agent:</label>
                <select id="agent_id" name="agent_id" required>
                    <option value="">-- Select Agent --</option>
                        <?php
                        $agents_query = "SELECT agent_id, CONCAT(fname, ' ', lname) AS full_name FROM agent";
                        $agents_result = $db_connection->query($agents_query);
                        while ($agent = $agents_result->fetch_assoc()) {
                            echo "<option value='{$agent['agent_id']}'>{$agent['full_name']}</option>";
                        }
                        ?>
                </select><br><br>
            </div>
            <div class="form-group">
                <label for="property_id">Property:</label>
                <select id="property_id" name="property_id" required>
                    <option value="">-- Select Property --</option>
                        <?php
                        $properties_query = "SELECT property_id, address FROM property WHERE status = 'For Sale'";
                        $properties_result = $db_connection->query($properties_query);
                        while ($property = $properties_result->fetch_assoc()) {
                            echo "<option value='{$property['property_id']}'>{$property['address']}</option>";
                        }
                        ?>
                </select><br><br>
            </div>
            <div class="form-group">
                <label for="transaction_date">Transaction Date:</label>
                <input type="date" id="transaction_date" name="transaction_date" required><br><br>
            </div>
            <div class="form-group">
                <label for="payment_status">Payment Status:</label>
                <select id="payment_status" name="payment_status" required>
                    <option value="">-- Select Payment Status --</option>
                    <option value="Complete">Complete</option>
                    <option value="Incomplete">Incomplete</option>
                </select><br><br>
            </div>

            <button type="submit" class="form-submit">Submit Transaction</button>
        </form>

        
    </div>


    <script>
    
    function openModal(modalId) {
        document.getElementById(modalId).style.display = 'flex';
    }

    
    function closeModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }
</script>



    <script src="../assets/js/script.js"></script>
</body>
</html>