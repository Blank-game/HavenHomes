<?php

require_once '../db/database.php';
require_once '../functions/auth_functions.php';

// Process form data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = trim($_POST['fname']);
    $lname = trim($_POST['lname']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $buyer_type = trim($_POST['buyer_type']);
    $password = trim($_POST['password']);
    
    // Register the user
    $result = registerUser($fname, $lname, $phone, $email, $buyer_type, $password);
    
    if ($result['success']) {
        header('Location: ../view/login.php?success=registered');
        exit();
    } else {
        header('Location: ../view/register.php?error=' . urlencode($result['message']));
        exit();
    }
}

?>