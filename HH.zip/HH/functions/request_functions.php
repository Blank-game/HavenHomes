<?php

require_once '../db/database.php';



function getPropertiesByUser($user_id) {
    $db = getDbConnection();

    $sql = "
        SELECT 
            p.property_id, p.address, p.price, p.property_type, p.image_url, p.status, pr.request_id, pr.request_date
        FROM 
            property_requests pr
        JOIN 
            property p ON pr.property_id = p.property_id
        WHERE 
            pr.user_id = ?
        ORDER BY 
            pr.request_date DESC
    ";

    $stmt = $db->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();

    $result = $stmt->get_result();

    $properties = [];
    while ($row = $result->fetch_assoc()) {
        $properties[] = $row;
    }

    $stmt->close();
    return $properties; // Returns an array of properties requested by the user
}



function getAllRequestedProperties() {
    $db = getDbConnection(); // Get database connection from your `database.php`

    $sql = "
        SELECT 
            u.fname AS first_name, 
            u.lname AS last_name, 
            u.phone, 
            u.email, 
            p.property_id, 
            p.address, 
            p.price, 
            p.property_type,
            p.image_url, 
            p.status,
            pr.request_id,
            pr.request_date
        FROM 
            property_requests pr
        JOIN 
            users u ON pr.user_id = u.user_id
        JOIN 
            property p ON pr.property_id = p.property_id
        ORDER BY 
            pr.request_date DESC
    ";

    $stmt = $db->prepare($sql);
    $stmt->execute();

    $result = $stmt->get_result();

    $requestedProperties = [];
    while ($row = $result->fetch_assoc()) {
        $requestedProperties[] = $row;
    }

    $stmt->close();
    return $requestedProperties; // Returns an array of all requested properties with user details
}


function deleteRequest($requestId) {
    $db = getDbConnection();
    $stmt = $db->prepare("DELETE FROM property_requests WHERE request_id = ?");
    $stmt->bind_param("i", $requestId);
    return $stmt->execute();
}


?>