<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <title>HavenHomes</title>
<style>
    body {
  font-family: Arial, sans-serif;
  background-color: #34495e;
}

h2 {
  text-align: center;
  color: white;
}

form {
  max-width: 400px;
  margin: 40px auto;
  padding: 20px;
  background-color: #fff;
  border: 1px solid #ddd;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

label {
  display: block;
  margin-bottom: 10px;
}

input[type="text"], input[type="email"], input[type="password"], select {
  width: 90%;
  height: 40px;
  margin-bottom: 20px;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

button[type="submit"] {
  width: 100%;
  height: 40px;
  background-color: #1abc9c;
  color: #fff;
  padding: 10px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

button[type="submit"]:hover {
  background-color: #16a085;
}

p {
  text-align: center;
  margin-top: 20px;
  color: white;
}

a {
  text-decoration: none;
  color: #1abc9c;
}

a:hover {
  color: #16a085;
}

.error {
  color: red;
  font-size: 12px;
  margin-bottom: 10px;
}

</style>
</head>
<body>
    <h2>Login</h2>
    <?php if (isset($_GET['error'])): ?>
        <p style="color: red;"><?php echo htmlspecialchars($_GET['error']); ?></p>
    <?php endif; ?>
    <form method="POST" action="../actions/login_user.php">
        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required>
        <br>
        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required>
        <br>
        <button type="submit">Login</button>
        
    </form>
    <p>Don't have an account? <a href="register.php">Register</a></p>
</body>
</html>