<?php
require_once '../db/database.php';

// Fetch all users from the database
function fetchUsers($db_connection) {
    $query = "SELECT * FROM users";
    $result = $db_connection->query($query);
    if (!$result) {
        die("Query failed: " . $db_connection->error);
    }
    return $result->fetch_all(MYSQLI_ASSOC);
}



// Fetch all agents from the database
function fetchAgents($db_connection) {
    $query = "SELECT * FROM agent";
    $result = $db_connection->query($query);
    if (!$result) {
        die("Query failed: " . $db_connection->error);
    }
    return $result->fetch_all(MYSQLI_ASSOC);
}


function getAgentById($id) {
    $db = getDbConnection();
    $query = "SELECT * FROM agent WHERE agent_id = ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $agent = $result->fetch_assoc();
    $stmt->close();
    closeDbConnection();
    return $agent;
}


?>