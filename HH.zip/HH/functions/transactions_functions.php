<?php


// Include database connection
require_once '../db/database.php';

function fetchAgents() {
    $db_connection = getDbConnection();
    $query = "SELECT agent_id, CONCAT(fname, ' ', lname) AS full_name FROM agent";
    $result = $db_connection->query($query);

    $agents = [];
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $agents[] = $row;
        }
    }

    return $agents;
}



?>