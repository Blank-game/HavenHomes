<?php

// Include the config.php to use database credentials
require_once 'config.php';

// Function to get the database connection
function getDbConnection() {
    global $db_connection;
    return $db_connection;
}

// Function to close the database connection (optional)
function closeDbConnection() {
    global $db_connection;
    if ($db_connection) {
        $db_connection->close();
    }
}



?>