<?php
// Include the database configuration file
require_once '../db/database.php';

// Check if 'id' is provided in the query string
if (isset($_GET['id'])) {
    // Get the transaction ID from the query string
    $transaction_id = intval($_GET['id']);

    // Prepare the DELETE query
    $delete_query = "DELETE FROM transactions WHERE transaction_id = ?";
    $stmt = $db_connection->prepare($delete_query);

    // Bind the transaction ID to the query
    $stmt->bind_param('i', $transaction_id);

    // Execute the query
    if ($stmt->execute()) {
        // Redirect back to the transactions table with a success message
        echo "<script>
            alert('Transaction deleted successfully!');
            window.location.href = '../view/table_data.php';
        </script>";
    } else {
        // Redirect back with an error message
        echo "Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
} else {
    // Redirect back if no ID is provided
    header("Location: table_data.php?message=Invalid request");
}

// Close the database connection
$db_connection->close();
?>