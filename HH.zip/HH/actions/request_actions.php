<?php
// Include database connection
//require_once '../db/database.php';
require_once '../functions/request_functions.php';

// Get the current logged-in user's ID (assumes session-based authentication)
$user_id = $_SESSION['user']['id']; // Make sure the user is logged in


// Get the property_id from the form submission
$property_id = isset($_POST['property_id']) ? $_POST['property_id'] : null;
//$property_id = $_POST['property_id'];



// Check if the property is already requested by the user
$check_sql = "SELECT * FROM property_requests WHERE user_id = ? AND property_id = ?";
$check_stmt = getDbConnection()->prepare($check_sql);
$check_stmt->bind_param("ii", $user_id, $property_id);
$check_stmt->execute();
$check_result = $check_stmt->get_result();

if ($check_result->num_rows > 0) {
    // Property already requested
    echo "<script>
        alert('Property already requested!');
        window.history.back();
    </script>";
} else {
    // Insert the request into the property_requests table
    $sql = "INSERT INTO property_requests (user_id, property_id) VALUES (?, ?)";
    $stmt = getDbConnection()->prepare($sql);
    $stmt->bind_param("ii", $user_id, $property_id);

    if ($stmt->execute()) {
        echo "<script>
            alert('Property request successfully submitted! Our agents will contact you shortly.');
            window.history.back();
        </script>";
    } 
    // else {
    //     echo "Error: " . $stmt->error;
    // }

    $stmt->close();
}

$check_stmt->close();




if (isset($_GET['delete_request_id'])) {
    $requestIdToDelete = intval($_GET['delete_request_id']);
    if (deleteRequest($requestIdToDelete)) {
        echo "<script>
            alert('Request deleted successfully!');
            window.location.href = 'request.php'; // Redirect to the same page
        </script>";
    } else {
        echo "<script>alert('Failed to delete the request.');</script>";
    }
}



?>
