<!DOCTYPE html>
<html>
<head>
    <title>HavenHomes</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
<style>
body {
  font-family: Arial, sans-serif;
  background-color: #34495e;
}

h2 {
  text-align: center;
  color: white;
}

form {
  max-width: 400px;
  margin: 40px auto;
  padding: 20px;
  background-color: #fff;
  border: 1px solid #ddd;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

label {
  display: block;
  margin-bottom: 10px;
}

input[type="text"], input[type="email"], input[type="password"], select {
  width: 90%;
  height: 40px;
  margin-bottom: 20px;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

button[type="submit"] {
  width: 100%;
  height: 40px;
  background-color: #1abc9c;
  color: #fff;
  padding: 10px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

button[type="submit"]:hover {
  background-color: #16a085;
}

p {
  text-align: center;
  margin-top: 20px;
  color: white;
}

a {
  text-decoration: none;
  color: #1abc9c;
}

a:hover {
  color: #16a085;
}

.error {
  color: red;
  font-size: 12px;
  margin-bottom: 10px;
}

</style>

</head>
<body>
    <h2>Register</h2>
    <?php if (isset($_GET['error'])): ?>
        <p style="color: red;"><?php echo htmlspecialchars($_GET['error']); ?></p>
    <?php endif; ?>
    <form method="POST" action="../actions/register_user.php">
        <label for="fname">First Name:</label>
        <input type="text" name="fname" id="fname" required>
        <br>
        <label for="lname">Last Name:</label>
        <input type="text" name="lname" id="lname" required>
        <br>
        <label for="phone">Phone:</label>
        <input type="text" name="phone" id="phone" required>
        <br>
        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required>
        <br>
        <label for="buyer_type">Buyer Type:</label>
<select name="buyer_type" id="buyer_type" required>
    <option value="">-- Select Buyer Type --</option>
    <option value="individual">Individual</option>
    <option value="couple">Couple</option>
    <option value="family">Family</option>
    <option value="individual_with_pet">Individual with Pet</option>
    <option value="couple_with_pet">Couple with Pet</option>
    <option value="family_with_pet">Family with Pet</option>
    <option value="group">Group</option>
    <option value="other">Other</option>
    <option value="prefer_not_to_say">Prefer Not To Say</option>
</select>
        <br>
        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required>
        <br>
        <button type="submit">Register</button>
    </form>
    <p>Have an account? <a href="login.php">Login</a></p>
</body>
</html>
