<?php

require_once '../db/database.php';


function loginUser($email, $password) {
    $db = getDbConnection();
    
    // Fetch user details
    $query = $db->prepare("SELECT user_id, fname, lname, phone, email, buyer_type, password, role FROM users WHERE email = ?");
    $query->bind_param("s", $email);
    $query->execute();
    $result = $query->get_result();
    
    if ($result->num_rows === 0) {
        return ['success' => false, 'message' => 'Invalid email or password'];
    }
    
    $user = $result->fetch_assoc();
    $query->close();
    
    // Verify password
    if (password_verify($password, $user['password'])) {
        // Store user data in session
        session_start();
        $_SESSION['user'] = [
            'id' => $user['user_id'],
            'fname' => $user['fname'],
            'lname' => $user['lname'],
            'phone' => $user['phone'],
            'email' => $user['email'],
            'buyer_type' => $user['buyer_type'],
            'role' => $user['role']
    
        ];
        
        return ['success' => true];
    } else {
        return ['success' => false, 'message' => 'Invalid email or password'];
    }
}


function isLoggedIn() {
    return isset($_SESSION['user']);
}



function registerUser($fname, $lname, $phone, $email, $buyer_type, $password) {
    $db = getDbConnection();
    
    // Check if email already exists
    $query = $db->prepare("SELECT email FROM users WHERE email = ?");
    $query->bind_param("s", $email);
    $query->execute();
    $query->store_result();
    
    if ($query->num_rows > 0) {
        return ['success' => false, 'message' => 'Email is already registered'];
    }
    
    $query->close();

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
    $role = 2; // Assign role 2 for user admin
    
    // Insert the user
    $query = $db->prepare("INSERT INTO users (fname, lname, phone, email, buyer_type, password, role) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $query->bind_param("ssssssi", $fname, $lname, $phone, $email, $buyer_type, $hashedPassword, $role);
    
    if ($query->execute()) {
        return ['success' => true];
    } else {
        return ['success' => false, 'message' => 'Registration failed. Please try again.'];
    }
}





?>