<?php
require_once '../db/database.php';


// Function to get all properties based on the selected type
function getProperties($property_type = null) {
    // Get the database connection
    $db_connection = getDbConnection();

    // Check if the connection is valid
    if (!$db_connection) {
        die("Database connection failed: " . $db_connection->connect_error);
    }

    // SQL query
    $query = "SELECT p.property_id, p.address, p.price, p.property_type, p.image_url, p.status, p.date_listed,
                     a.num_rooms AS num_rooms_apartment, a.num_bathrooms AS num_bathrooms_apartment, a.num_floors AS num_floors_apartment,
                     b.num_rooms AS num_rooms_bungalow, b.num_bathrooms AS num_bathrooms_bungalow, b.num_floors AS num_floors_bungalow, b.lot_size AS lot_size_bungalow,
                     d.num_rooms AS num_rooms_detached, d.num_bathrooms AS num_bathrooms_detached, d.garage_size, d.parking_space, d.lot_size AS lot_size_detached,
                     m.num_rooms AS num_rooms_mansion, m.num_bathrooms AS num_bathrooms_mansion, m.luxury_features, m.lot_size AS lot_size_mansion
              FROM Property p
              LEFT JOIN Apartment a ON p.property_id = a.property_id
              LEFT JOIN Bungalow b ON p.property_id = b.property_id
              LEFT JOIN Detached_House d ON p.property_id = d.property_id
              LEFT JOIN Mansion m ON p.property_id = m.property_id";

    // If a property type is selected, add a WHERE condition
    if ($property_type) {
        $query .= " WHERE p.property_type = ?";
    }

    // Prepare and execute the statement
    $stmt = $db_connection->prepare($query);
    if ($property_type) {
        $stmt->bind_param("s", $property_type);  // 's' means string
    }
    $stmt->execute();

    // Fetch the result
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);  // Return as an associative array
}

// Example: Fetch properties (this would be called when the page loads or when a filter is selected)
$properties = getProperties();  // All properties
// If "Apartments" is selected, use:
// $properties = getProperties('apartment');



function deleteProperty($propertyId) {
    $db = getDbConnection();
    $stmt = $db->prepare("DELETE FROM property WHERE property_id = ?");
    $stmt->bind_param("i", $propertyId);
    return $stmt->execute();
}


// Function to get properties with "For Sale" status based on the selected type
function getPropertiesForSale($property_type = null) {
    // Get the database connection
    $db_connection = getDbConnection();

    // Check if the connection is valid
    if (!$db_connection) {
        die("Database connection failed: " . $db_connection->connect_error);
    }

    // Base SQL query
    $query = "SELECT p.property_id, p.address, p.price, p.property_type, p.image_url, p.status, p.date_listed,
                     a.num_rooms AS num_rooms_apartment, a.num_bathrooms AS num_bathrooms_apartment, a.num_floors AS num_floors_apartment,
                     b.num_rooms AS num_rooms_bungalow, b.num_bathrooms AS num_bathrooms_bungalow, b.num_floors AS num_floors_bungalow, b.lot_size AS lot_size_bungalow,
                     d.num_rooms AS num_rooms_detached, d.num_bathrooms AS num_bathrooms_detached, d.garage_size, d.parking_space, d.lot_size AS lot_size_detached,
                     m.num_rooms AS num_rooms_mansion, m.num_bathrooms AS num_bathrooms_mansion, m.luxury_features, m.lot_size AS lot_size_mansion
              FROM Property p
              LEFT JOIN Apartment a ON p.property_id = a.property_id
              LEFT JOIN Bungalow b ON p.property_id = b.property_id
              LEFT JOIN Detached_House d ON p.property_id = d.property_id
              LEFT JOIN Mansion m ON p.property_id = m.property_id
              WHERE p.status = 'For Sale'";

    // If a property type is selected, add a condition for it
    if ($property_type) {
        $query .= " AND p.property_type = ?";
    }

    // Prepare and execute the statement
    $stmt = $db_connection->prepare($query);
    if ($property_type) {
        $stmt->bind_param("s", $property_type);  // 's' means string
    }
    $stmt->execute();

    // Fetch the result
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);  // Return as an associative array
}


$propertiesForSale = getPropertiesForSale();  // All properties with "For Sale" status



?>