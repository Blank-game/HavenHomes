<?php

// Include database configuration
require_once '../db/database.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $user_id = intval($_POST['user_id']);
    $agent_id = intval($_POST['agent_id']);
    $property_id = intval($_POST['property_id']);
    $transaction_date = $_POST['transaction_date'];
    $payment_status = $_POST['payment_status'];

    // Validate inputs
    if (!empty($user_id) && !empty($agent_id) && !empty($property_id) && !empty($transaction_date) && !empty($payment_status)) {
        // Prepare the INSERT statement
        $stmt = $db_connection->prepare("
            INSERT INTO transactions (user_id, agent_id, property_id, transaction_date, payment_status)
            VALUES (?, ?, ?, ?, ?)
        ");

        // Bind parameters to the prepared statement
        $stmt->bind_param('iiiss', $user_id, $agent_id, $property_id, $transaction_date, $payment_status);

        // Execute the statement
        if ($stmt->execute()) {
           // echo "Transaction successfully recorded!";
            echo "<script>
            alert('Transaction successfully recorded!');
            window.location.href = '../view/table_data.php';
        </script>";
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        echo "All fields are required.";
    }

    
}




$sql = "SELECT 
            t.transaction_id,
            CONCAT(u.fname, ' ', u.lname) AS user_full_name,
            CONCAT(a.fname, ' ', a.lname) AS agent_full_name,
            p.address AS property_address,
            t.transaction_date,
            t.payment_status
        FROM transactions t
        JOIN users u ON t.user_id = u.user_id
        JOIN agent a ON t.agent_id = a.agent_id
        JOIN property p ON t.property_id = p.property_id";

$result = $db_connection->query($sql);




?>